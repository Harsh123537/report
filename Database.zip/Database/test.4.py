from sqlalchemy import create_engine,text
import pandas as pd
import pdfkit
import os
import pytz
from datetime import datetime
from configparser import ConfigParser
import oracledb
import chardet
oracledb.init_oracle_client(lib_dir=r"C:\Users\M685200\Downloads\instantclient-basic-windows.x64-23.26.0.0.0\instantclient_23_0")
oracledb.defaults.encoding = "UTF-8"
oracledb.defaults.nencoding = "UTF-8"
properties = ConfigParser()
properties.read('properties.ini')
folder_name=properties["NAME"]['folder']
os.makedirs(folder_name, exist_ok=True)
HEADER_NAME=properties['PATH']['HEADER_FILE']
BASE_NAME=properties['PATH']['BASE_FILE']
FOOTER_NAME=properties["PATH"]['FOOTER_FILE']
HEADER_FILE = "file:///" + os.path.abspath(HEADER_NAME).replace("\\", "/")
HEADER_FILE1 = os.path.abspath(HEADER_NAME).replace("\\", "/")
BASE_FILE=os.path.abspath(BASE_NAME).replace("\\", "/")
FOOTER_FILE="file:///" + os.path.abspath(FOOTER_NAME).replace("\\", "/")
FOOTER_FILE1=os.path.abspath(FOOTER_NAME).replace("\\", "/")

Pr_List=properties['PATH']['Pr_List']

UTC = pytz.utc
datetime_utc = datetime.now(UTC)


username = properties['DATABASE']['username']
password = properties['DATABASE']['password']
host = properties['DATABASE']['host']
port = properties['DATABASE']['port']
service = properties['DATABASE']['service']

# Correct engine for python-oracledb
engine = create_engine(
    f"oracle+oracledb://{username}:{password}@{host}:{port}/?service_name={service}"
)




# Read PR IDs
with open(Pr_List, 'r') as f:
    pr_ids = [line.strip() for line in f]

# Build placeholders :1, :2, ...
placeholders = ",".join([f":{i+1}" for i in range(len(pr_ids))])

# Build query
base_query = properties['QUERY']['query']

query = f"""
{base_query}
WHERE pe.pr_id IN ({placeholders})
ORDER BY pe.pr_id, pet.name
"""

# Execute query
df = pd.read_sql(query, engine, params=tuple(pr_ids))

def inplace_change(filename, old_string, new_string): 
    with open(filename,'r',encoding='utf-8') as f: 
        s = f.read() 
    with open(filename, 'w',encoding='utf-8') as f: 
        s = s.replace(old_string, new_string) 
        f.write(s)
inplace_change(BASE_FILE,'#title',f"{properties['NAME']['title']}")
inplace_change(FOOTER_FILE1,'#person',f"{properties['NAME']['person']}")
inplace_change(FOOTER_FILE1,'#date',f"{datetime_utc.strftime('%d %B %Y, %I:%M %p')}")

l=pr_ids


path_wkhtmltopdf = properties["PATH"]['wkhtmltopdf']
config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)

person=properties['NAME']['person']

for pr_id in l:
    result = df[df[df.columns[2]] ==int(pr_id)]
    row=result.iloc[0]
    A= row.iloc[0]
    B = row.iloc[1]
    C = row.iloc[2]
    D = row.iloc[3]
    E=df.columns[0]
    F=df.columns[1]
    G=df.columns[2]
    H=df.columns[3]
    print(A,B)

    with open(BASE_FILE, 'r', encoding='utf-8') as base_file:
        content = base_file.read()

    with open(HEADER_FILE1, 'w', encoding='utf-8') as header_file:
        header_file.write(content)
    inplace_change(HEADER_FILE1,"#value1",f"{A}")
    inplace_change(HEADER_FILE1,"#value2",f"{B}")
    inplace_change(HEADER_FILE1,"#value3",f"{C}")
    inplace_change(HEADER_FILE1,"#value4",f"{D}")
    inplace_change(HEADER_FILE1,"#column1",f"{E}")
    inplace_change(HEADER_FILE1,"#column2",f"{F}")
    inplace_change(HEADER_FILE1,"#column3",f"{G}")
    inplace_change(HEADER_FILE1,"#column4",f"{H}")
    
    options = {
        "page-size": "A4",
        "margin-top": "53mm",
        "margin-right": "7mm",
        "margin-bottom": "18mm",
        "margin-left": "7mm",

        # HEADER
        "header-html": HEADER_FILE,       # ABSOLUTE PATH
        "header-spacing": "17",

        # MISC
        "enable-local-file-access": None,
        "dpi": 185,
        "zoom": 1.0,
        "disable-smart-shrinking": "",
        'footer-html':FOOTER_FILE,
        'footer-font-size':'6',
        'header-font-size':'6',
        "encoding": "UTF-8",
        "lowquality": None,
        'footer-spacing': '4',
        "orientation": "Landscape",

        # IN-PLACE REPLACEMENT (dynamic values)
    }
    body=properties['NAME']['body_html_name'].format(pr_id=pr_id)
    open(body, "w", encoding="utf-8").close()
    f1 = open(body,"a",encoding='utf-8')
    f1.write(f'''<html><head>
    <meta charset='UTF-8'><style>
    * {{

    font-size: 9pt !important;
    

    }}
    table, th, td {{
    border: 1px solid black;
    font-size: 9pt !important;
    }}
    .label {{
        font-family: 'Arial', sans-serif !important;
        font-weight: bold;
        color: #623C80;
        padding-bottom: 0px;  /* Adds space below title */
        border-bottom: 1px solid #623C80; /* Custom underline */
        display: inline-block;
        line-height: 1;
        margin-left: 10pt;
    }}
    .value {{
        font-family: 'ArialUnicodeMS', sans-serif !important;
        margin-left: 10pt;
    }} 
            
    </style> </head><body>''')
    f1.close()
    for i in range(len(result)):
        f1 = open(body,"a",encoding='utf-8')
        f1.write(f"<div class='label'>{result.iloc[i, 4]}:</div>")
        f1.write(f"<br><br>")
        f1.write(f"<div class='value'>{result.iloc[i, 5]}</tr></td></table><tbody></div><br><br>\n")
        # f1.write(f"<div class='divider'></div>")
        f1.write(f"<hr>")
    
    f1.write("</body></html>")
    f1.close()
    report_name=properties["NAME"]['report'].format(pr_id=pr_id)
    pdfkit.from_file(
        body,
        f"folder3/{report_name}",
        configuration=config,
        options=options
    )
    print(f"PDF generated: {os.path.abspath(f"{folder_name}/{report_name}")}")


inplace_change(BASE_FILE,f"{properties['NAME']['title']}",'#title')
inplace_change(FOOTER_FILE1,f"{properties['NAME']['person']}",'#person')
inplace_change(FOOTER_FILE1,f"{datetime_utc.strftime('%d %B %Y, %I:%M %p')}",'#date')

