from sqlalchemy import create_engine
import pandas as pd
import pdfkit
import os
import pytz
from datetime import datetime
from configparser import ConfigParser
properties = ConfigParser()
properties.read('properties.ini')
folder_name=properties["NAME"]['folder']
os.makedirs(folder_name, exist_ok=True)
HEADER_NAME=properties['PATH']['HEADER_FILE']
BASE_NAME=properties['PATH']['BASE_FILE']
FOOTER_NAME=properties["PATH"]['FOOTER_FILE']
HEADER_FILE = "file:///" + os.path.abspath(HEADER_NAME).replace("\\", "/")
HEADER_FILE1 = os.path.abspath(HEADER_NAME).replace("\\", "/")
BASE_FILE=os.path.abspath(BASE_NAME).replace("\\", "/")
FOOTER_FILE="file:///" + os.path.abspath(FOOTER_NAME).replace("\\", "/")
FOOTER_FILE1=os.path.abspath(FOOTER_NAME).replace("\\", "/")

Pr_List=properties['PATH']['Pr_List']

UTC = pytz.utc
datetime_utc = datetime.now(UTC)


server=properties['DATABASE']['server']
database=properties['DATABASE']['database']
username=properties['DATABASE']['username']
password=properties['DATABASE']['password']

 
# Create SQLAlchemy engine
engine = create_engine(
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server"
    
)
l=[]
with open(Pr_List,'r') as f:
    for i in f:
        l.append(i.strip())
pr_ids=','.join(l)
placeholders = ",".join("?" * len(pr_ids))
params = {f"id{i}": v for i, v in enumerate(pr_ids)}

query = properties['QUERY']['query'].format(pr_ids=pr_ids)
        
df = pd.read_sql(query, engine)
def inplace_change(filename, old_string, new_string): 
    with open(filename) as f: 
        s = f.read() 
    with open(filename, 'w') as f: 
        s = s.replace(old_string, new_string) 
        f.write(s)
inplace_change(BASE_FILE,'#title',f"{properties['NAME']['title']}")
inplace_change(FOOTER_FILE1,'#person',f"{properties['NAME']['person']}")
inplace_change(FOOTER_FILE1,'#date',f"{datetime_utc.strftime('%d %B %Y, %I:%M %p')}")

l=pr_ids.split(',')


path_wkhtmltopdf = properties["PATH"]['wkhtmltopdf']
config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)

person=properties['NAME']['person']

for pr_id in l:
    result = df[df[df.columns[2]] ==int(pr_id)]
    row=result.iloc[0]
    A= row.iloc[0]
    B = row.iloc[1]
    C = row.iloc[2]
    D = row.iloc[3]
    E=df.columns[0]
    F=df.columns[1]
    G=df.columns[2]
    H=df.columns[3]

    with open(BASE_FILE, 'r', encoding='utf-8') as base_file:
        content = base_file.read()

    with open(HEADER_FILE1, 'w', encoding='utf-8') as header_file:
        header_file.write(content)
    inplace_change(HEADER_FILE1,"#value1",f"{A}")
    inplace_change(HEADER_FILE1,"#value2",f"{B}")
    inplace_change(HEADER_FILE1,"#value3",f"{C}")
    inplace_change(HEADER_FILE1,"#value4",f"{D}")
    inplace_change(HEADER_FILE1,"#column1",f"{E}")
    inplace_change(HEADER_FILE1,"#column2",f"{F}")
    inplace_change(HEADER_FILE1,"#column3",f"{G}")
    inplace_change(HEADER_FILE1,"#column4",f"{H}")
    def generate_pdf():
    
        options = {
            "page-size": "A4",
            "margin-top": "53mm",
            "margin-right": "7mm",
            "margin-bottom": "18mm",
            "margin-left": "7mm",

            # HEADER
            "header-html": HEADER_FILE,       # ABSOLUTE PATH
            "header-spacing": "17",

            # MISC
            "enable-local-file-access": None,
            "dpi": 185,
            "zoom": 1.0,
            "disable-smart-shrinking": "",
            'footer-html':FOOTER_FILE,
            'footer-font-size':'6',
            'header-font-size':'6',
            "encoding": "UTF-8",
            "lowquality": None,
            'footer-spacing': '4',
            "orientation": "Landscape",

            # IN-PLACE REPLACEMENT (dynamic values)
        }
        body=properties['NAME']['body_html_name'].format(pr_id=pr_id)
        open(body, "w", encoding="utf-8").close()
        f1 = open(body,"a",encoding='utf-8')
        f1.write(f'''<html><head>
        <meta charset='UTF-8'><style>
        * {{

        font-size: 9pt !important;
        

        }}
        table, th, td {{
        border: 1px solid black;
        font-size: 9pt !important;
        }}
        .label {{
            font-family: 'Arial', sans-serif !important;
            font-weight: bold;
            color: #623C80;
            padding-bottom: 0px;  /* Adds space below title */
            border-bottom: 1px solid #623C80; /* Custom underline */
            display: inline-block;
            line-height: 1;
            margin-left: 10pt;
        }}
        .value {{
            font-family: 'ArialUnicodeMS', sans-serif !important;
            margin-left: 10pt;
        }} 
              
        </style> </head><body>''')
        f1.close()
        for i in range(len(result)):
            f1 = open(body,"a",encoding='utf-8')
            f1.write(f"<div class='label'>{result.iloc[i, 4]}:</div>")
            f1.write(f"<br><br>")
            f1.write(f"<div class='value'>{result.iloc[i, 5]}</tr></td></table><tbody></div><br><br>\n")
            # f1.write(f"<div class='divider'></div>")
            f1.write(f"<hr>")
       
        f1.write("</body></html>")
        f1.close()
        report_name=properties["NAME"]['report'].format(pr_id=pr_id)
        pdfkit.from_file(
            body,
            f"folder/{report_name}",
            configuration=config,
            options=options
        )
        print(f"PDF generated: {os.path.abspath(f"{folder_name}/{report_name}")}")


# ------------------------------------------------------------------
# 3. Run
# ------------------------------------------------------------------
    if __name__ == "__main__":
        generate_pdf()

# with open(BASE_FILE, 'r', encoding='utf-8') as base_file:
#         content = base_file.read()

# with open(HEADER_FILE1, 'w', encoding='utf-8') as header_file:
#     header_file.write(content)


inplace_change(BASE_FILE,f"{properties['NAME']['title']}",'#title')
inplace_change(FOOTER_FILE1,f"{properties['NAME']['person']}",'#person')
inplace_change(FOOTER_FILE1,f"{datetime_utc.strftime('%d %B %Y, %I:%M %p')}",'#date')

