from sqlalchemy import create_engine
import pandas as pd
import pdfkit
import os
import pytz
from datetime import datetime
from configparser import ConfigParser
properties = ConfigParser()
properties.read('properties.ini')
os.makedirs("folder1", exist_ok=True)
HEADER_FILE = "file:///" + os.path.abspath(properties['PATH']['HEADER_FILE']).replace("\\", "/")
HEADER_FILE1 = os.path.abspath(properties['PATH']['HEADER_FILE']).replace("\\", "/")
BASE_FILE=os.path.abspath(properties['PATH']['BASE_FILE']).replace("\\", "/")

mapping_file=properties['PATH']['mapping_file']

UTC = pytz.utc
datetime_utc = datetime.now(UTC)


server=properties['DATABASE']['server']
database=properties['DATABASE']['database']
username=properties['DATABASE']['username']
password=properties['DATABASE']['password']
 
# Create SQLAlchemy engine
engine = create_engine(
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server"
)
l=[]
with open(properties["PATH"]['MAPPING_FILE'],'r') as f:
    for i in f:
        l.append(i.strip())
pr_ids=','.join(l)
placeholders = ",".join("?" * len(pr_ids))
params = {f"id{i}": v for i, v in enumerate(pr_ids)}

query = f"""SELECT dt.name AS Division,p.name AS Project, pe.pr_id 'PR ID',  pst.name AS 'PR State', pet.name AS DataField_Name, pe.text_data AS Text FROM pr_element pe INNER JOIN pr_element_type pet ON pet.id = pe.pr_element_type INNER JOIN PR pr1 ON pr1.id = pe.pr_id LEFT JOIN project p ON p.id = pr1.project_id LEFT JOIN pr_status_type pst ON pst.id = pr1.status_type LEFT JOIN division_type dt ON p.division_type = dt.id WHERE pe.pr_id in ({pr_ids}) ORDER BY pr_id, pet.name"""
        
df = pd.read_sql(query, engine)
l=pr_ids.split(',')


path_wkhtmltopdf = r"C:\Users\M685200\OneDrive - Mylan Inc\wkhtmltox-0.12.5-1.mxe-cross-win32\wkhtmltox-0.12.5-1.mxe-cross-win32\wkhtmltox\bin\wkhtmltopdf.exe"
config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)

# HEADER_FILE = os.path.abspath("header.html")  # ABSOLUTE PATH



# ------------------------------------------------------------------
# 2. Generate PDF
# ------------------------------------------------------------------
person=properties['NAME']['person']
print(person)
open(f"footer.html", "w", encoding="utf-8").close()
with open(f"footer.html","a",encoding='utf-8') as f:
    f.write(f"""<html><head><meta charset='UTF-8'>
    <style>
      body {{
        font-family: Arial, sans-serif;
        font-size: 6pt;
        color: black;
        text-align: left;
        margin: 0;
        padding-left: 2mm;
        padding-bottom: 5mm;
            
      }}
    </style></head><body>
   <b>Report Run by:</b> {person} on {datetime_utc.strftime('%d %B %Y, %I:%M %p')} (GMT)
    </body></html>""")
FOOTER_FILE="file:///" + os.path.abspath("footer.html").replace("\\", "/")
for pr_id in l:
    result = df[df[df.columns[2]] ==int(pr_id)]
    row=result.iloc[0]
    A= row.iloc[0]
    B = row.iloc[1]
    C = row.iloc[2]
    D = row.iloc[3]
    E=df.columns[0]
    F=df.columns[1]
    G=df.columns[2]
    H=df.columns[3]


    def inplace_change(filename, old_string, new_string): 
        with open(filename) as f: 
            s = f.read() 
        with open(filename, 'w') as f: 
            s = s.replace(old_string, new_string) 
            f.write(s)
    with open(BASE_FILE, 'r', encoding='utf-8') as base_file:
        content = base_file.read()

    with open(HEADER_FILE1, 'w', encoding='utf-8') as header_file:
        header_file.write(content)
    inplace_change(HEADER_FILE1,"#value1",f"{A}")
    inplace_change(HEADER_FILE1,"#value2",f"{B}")
    inplace_change(HEADER_FILE1,"#value3",f"{C}")
    inplace_change(HEADER_FILE1,"#value4",f"{D}")
    inplace_change(HEADER_FILE1,"#column1",f"{E}")
    inplace_change(HEADER_FILE1,"#column2",f"{F}")
    inplace_change(HEADER_FILE1,"#column3",f"{G}")
    inplace_change(HEADER_FILE1,"#column4",f"{H}")
    def generate_pdf():
    
        options = {
            "page-size": "A4",
            "margin-top": "46mm",
            "margin-right": "5mm",
            "margin-bottom": "10mm",
            "margin-left": "5mm",

            # HEADER
            "header-html": HEADER_FILE,       # ABSOLUTE PATH
            "header-spacing": "5",

            # MISC
            "enable-local-file-access": None,
            "dpi": 185,
            "zoom": 1.0,
            "disable-smart-shrinking": "",
            'footer-html':FOOTER_FILE,
            'footer-font-size':'6',
            'header-font-size':'6',
            "encoding": "UTF-8",
            "lowquality": None,
            'footer-spacing': '4',
            "orientation": "Landscape",

            # IN-PLACE REPLACEMENT (dynamic values)
        }
        open(f"{pr_id}_body.html", "w", encoding="utf-8").close()
        f1 = open(f"{pr_id}_body.html","a",encoding='utf-8')
        f1.write(f'''<html><head>
        <meta charset='UTF-8'><style>
        * {{

        font-size: 9pt !important;

        }}
        table, th, td {{
        border: 1px solid black;
        font-size: 9pt !important;
        }}
        .label {{
            font-family: 'Arial', sans-serif !important;
            font-weight: bold;
            color: #623C80;
            padding-bottom: 0px;  /* Adds space below title */
            border-bottom: 1px solid #623C80; /* Custom underline */
            display: inline-block;
            line-height: 1;
        }}
        .value {{
            font-family: 'ArialUnicodeMS', sans-serif !important;
        }} 
              
        </style> </head><body>''')
        for i in range(len(result)):
            f1 = open(f"{pr_id}_body.html","a",encoding='utf-8')
            f1.write(f"<div class='label'>{result.iloc[i, 4]}:</div>")
            f1.write(f"<br><br>")
            f1.write(f"<div class='value'>{result.iloc[i, 5]}</tr></td></table><tbody></div><br><br>\n")
            # f1.write(f"<div class='divider'></div>")
            f1.write(f"<hr>")
       
        f1.write("</body></html>")
        pdfkit.from_file(
            f"{pr_id}_body.html",
            f"folder1/{pr_id}_flexfield_report.pdf",
            configuration=config,
            options=options
        )
        print(f"PDF generated: {os.path.abspath(f"folder/{pr_id}_flexfield_report.pdf")}")


# ------------------------------------------------------------------
# 3. Run
# ------------------------------------------------------------------
    if __name__ == "__main__":
        generate_pdf()





