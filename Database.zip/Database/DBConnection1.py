from sqlalchemy import create_engine
import pandas as pd
import pdfkit
import os
import pytz
from datetime import datetime
HEADER_FILE = "file:///" + os.path.abspath("header.html").replace("\\", "/")
HEADER_FILE1 = os.path.abspath("header.html").replace("\\", "/")

LOGO_PATH   = os.path.abspath(r"C:\Users\Harsh Agrawal\Documents\REPORT\logo.png")
LOGO_URL    = f"file:///{LOGO_PATH.replace(os.sep, '/')}"

UTC = pytz.utc
datetime_utc = datetime.now(UTC)
footer_left = 'Report Run by & on: Administrator on ' + datetime_utc.strftime('%d-%b-%Y %H:%M:%S') + ' GMT'

server = 'W0BTWAGILA001\\twagila001,1433'
database = 'twprod'
username = 'sysadm'
password = 'sysadm'
 
# Create SQLAlchemy engine
engine = create_engine(
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server"
)
pr_ids=64869
# datafield_names=
# Query
query = f"""SELECT pe.pr_id PR_ID, p.name AS Project, pst.name AS State, dt.name AS Division, pet.name AS DataField_Name, pe.text_data AS Text FROM pr_element pe INNER JOIN pr_element_type pet ON pet.id = pe.pr_element_type INNER JOIN PR pr1 ON pr1.id = pe.pr_id LEFT JOIN project p ON p.id = pr1.project_id LEFT JOIN pr_status_type pst ON pst.id = pr1.status_type LEFT JOIN division_type dt ON p.division_type = dt.id WHERE pe.pr_id = {pr_ids} ORDER BY pr_id, pet.name"""
 
# Load to DataFrame
df = pd.read_sql(query, engine)
df1 = df
df.dropna(inplace=True)
df1.dropna(inplace=True)
df = df.set_index("DataField_Name")["Text"].to_frame().T
df.reset_index(drop=True, inplace=True)

def get_value(col):
    return df1[col].values[0] if col in df1.columns else ""

pr_id = get_value("PR_ID")
project = get_value("Project")
pr_state = get_value("State")
division = get_value("Division")
def inplace_change(filename, old_string, new_string): 
    with open(filename) as f: 
        s = f.read() 
    with open(filename, 'w') as f: 
        s = s.replace(old_string, new_string) 
        f.write(s)
inplace_change(HEADER_FILE1,"#prid",f"{pr_id}")
inplace_change(HEADER_FILE1,"#project",f"{project}")
inplace_change(HEADER_FILE1,"#division",f"{division}")
inplace_change(HEADER_FILE1,"#prstate",f"{pr_state}")


path_wkhtmltopdf = r"C:\Users\M685200\OneDrive - Mylan Inc\wkhtmltox-0.12.5-1.mxe-cross-win32\wkhtmltox-0.12.5-1.mxe-cross-win32\wkhtmltox\bin\wkhtmltopdf.exe"
config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)

# HEADER_FILE = os.path.abspath("header.html")  # ABSOLUTE PATH



# ------------------------------------------------------------------
# 2. Generate PDF
# ------------------------------------------------------------------
def generate_pdf(division, project, pr_id, pr_state, run_date):
    
    options = {
        "page-size": "A4",
        "margin-top": "43mm",
        "margin-right": "5mm",
        "margin-bottom": "10mm",
        "margin-left": "5mm",

        # HEADER
        "header-html": HEADER_FILE,       # ABSOLUTE PATH
        "header-spacing": "5",

        # MISC
        "enable-local-file-access": None,
        "dpi": 185,
        "zoom": 1.0,
        "disable-smart-shrinking": "",
        'footer-left':footer_left,
        'footer-font-size':'6',
        'header-font-size':'6',
        "encoding": "UTF-8",
        "lowquality": None

        # IN-PLACE REPLACEMENT (dynamic values)
    }
    open("body.html", "w", encoding="utf-8").close()
    f1 = open("body.html","a",encoding='utf-8')
    f1.write(f'''<style>
* {{
  font-family: Calibri, sans-serif !important;
  font-size: 10px !important;
}}
table, th, td {{
  border: 1px solid black;
  font-size: 10px !important;
}}
p, span, b {{
  font-size: 10px !important;
}}        
</style>''')
    for index, row in df.iterrows():
        for column in df.columns:
            f1 = open("body.html","a",encoding='utf-8')
            f1.write(f"<b>{column}:</b>")
            f1.write(f"<br>")
            f1.write(f"{row[column]}</tr></td></table><tbody><br><br>\n")
    pdfkit.from_file(
        "body.html",
        "flexfield_report.pdf",
        configuration=config,
        options=options
    )
    print(f"PDF generated: {os.path.abspath('flexfield_report.pdf')}")


# ------------------------------------------------------------------
# 3. Run
# ------------------------------------------------------------------
if __name__ == "__main__":
    generate_pdf(
        division="Weesp",
        project="Change Request",
        pr_id="31471",
        pr_state="Closed",
        run_date="27 October 2025, 06:07 PM (GMT)"
    )
 
# Connection string
server = 'W0BTWAGILA001\\twagila001,1433'
database = 'twprod'
username = 'sysadm'
password = 'sysadm'
 
# Create SQLAlchemy engine
engine = create_engine(
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server"
)
pr_ids=64869
# datafield_names=
# Query
query = f"""SELECT pe.pr_id PR_ID, p.name AS Project, pst.name AS State, dt.name AS Division, pet.name AS DataField_Name, pe.text_data AS Text FROM pr_element pe INNER JOIN pr_element_type pet ON pet.id = pe.pr_element_type INNER JOIN PR pr1 ON pr1.id = pe.pr_id LEFT JOIN project p ON p.id = pr1.project_id LEFT JOIN pr_status_type pst ON pst.id = pr1.status_type LEFT JOIN division_type dt ON p.division_type = dt.id WHERE pe.pr_id = {pr_ids} ORDER BY pr_id, pet.name"""
 
# Load to DataFrame
df = pd.read_sql(query, engine)
 
